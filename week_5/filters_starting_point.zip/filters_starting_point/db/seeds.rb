Team.delete_all

Team.create!(name: 'Moutohora Macaws', founded: '1 March 1872', mascot: 'Sparky')
Team.create!(name: 'Ballycastle Bats', founded: '6 November 1887', mascot: 'Barny the Fruitbat')
Team.create!(name: 'Kenmare Kestrels', founded: '24 May 1909', mascot: 'Kez')