window.onload = function(){
  console.log('App started');
};
