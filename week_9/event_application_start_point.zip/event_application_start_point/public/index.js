window.onload = function(){
  console.log('app started');
};
